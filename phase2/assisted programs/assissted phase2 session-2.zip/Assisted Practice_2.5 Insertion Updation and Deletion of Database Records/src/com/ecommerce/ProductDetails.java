package com.ecommerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
        private static final long serialVersionUID = 1L;
       
   
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }
 
       
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                // TODO Auto-generated method stub
                
                try {
                         PrintWriter out = response.getWriter();
                         out.println("<html><body>");
                        
                        Connection conn=DBConnection.getMyConnection();
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                        stmt.executeUpdate("insert into Product (Prod_id, Prod_name, price, quantity) values (12, 'Scale', 10.00, 5)");
                        out.println("Executed an insert operation<br>");
                        
                        stmt.executeUpdate("update Product set price=2000 where Prod_name = 'Bag'");
                        out.println("Executed an update operation<br>");
                        
                        stmt.executeUpdate("delete from Product where Prod_name = 'Scale'");
                        out.println("Executed a delete operation<br>");
                        
                        stmt.close();
    
                        out.println("</body></html>");
                       
                        
                }  catch (SQLException e) {
                        e.printStackTrace();
                }
        }
 
       
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                // TODO Auto-generated method stub
                doGet(request, response);
        }
 
}
